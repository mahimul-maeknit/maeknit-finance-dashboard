// types/garment-settings.ts
